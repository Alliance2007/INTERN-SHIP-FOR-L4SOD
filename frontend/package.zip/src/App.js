import './App.css';
import Home from './component/Home';
import Modules from './component/Modules';
import Exams from './component/Exams';
import About from './component/About';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import NavBar from './component/NavBar';

function App() {
  return (
    <Router>
      <h1 className="text-4xl font-extrabold text-blue-600 text-center mt-8">
  FULL STACK NI MR ALLI
</h1>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/modules" element={<Modules />} />
        <Route path="/exams" element={<Exams />} />
        <Route path="/about" element={<About/>} />
      </Routes>
    </Router>
    
    
  );
}
export default App;