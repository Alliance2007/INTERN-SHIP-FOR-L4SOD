import React, { useState } from "react";
import NavBar from "./NavBar";

function About() {
  const [like, setLike] = useState(0);

  const handleLike = () => {
    setLike(prev => prev + 1);
  };

  return (
    <>
      <NavBar />

      <div className="text-center mt-10">
        <p>GS GIHOGWE CATHOLIQUE / TSS</p>

        <p className="mt-3 text-xl font-bold">
          LIKES: {like}
        </p>

        <button
          onClick={handleLike}
          className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          CLICK TO LIKE 👍
        </button>
      </div>
    </>
  );
}

export default About;