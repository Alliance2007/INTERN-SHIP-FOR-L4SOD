import React, { useState } from "react";
import NavBar from "./NavBar";

function Exams() {
  const [name, setName] = useState("");
  const [displayName, setDisplayName] = useState("");

  const handleChange = (e) => {
    setName(e.target.value);
  };

  const handleName = () => {
    if (name.trim() === "") return;
    setDisplayName(name);
  };

  return (
    <>
      <NavBar />

      <div className="bg-orange-300 mt-5 p-3 rounded-lg">
        <h1 className="bg-green-400 text-white py-7 text-4xl rounded-2xl">
          THIS IS EXAMINATION FOR L4OD
        </h1>

        <ul className="space-y-3 mt-4">
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            1. DATABASE DEVELOPMENT
          </li>
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            2. BACKEND SYSTEM DESIGN
          </li>
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            3. DATA STRUCTURE AND ALGORITHM
          </li>
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            4. BACKEND APPLICATION DEVELOPMENT
          </li>
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            5. PHP PROGRAMMING
          </li>
        </ul>
      </div>

      <div>
        <label className="mt-3 font-bold">ENTER YOUR NAME:</label>
        <br />

        <input
          type="text"
          value={name}
          onChange={handleChange}
          placeholder="Enter your name"
          className="bg-green-500 rounded-full p-2 mt-2"
        />

        <button
          onClick={handleName}
          className="bg-yellow-500 hover:bg-blue-300 rounded-full font-bold ml-2 p-2"
        >
          OK🫡
        </button>

        <p className="mt-3 font-bold">
          MY NAME IS: {displayName}
        </p>
      </div>
    </>
  );
}

export default Exams;