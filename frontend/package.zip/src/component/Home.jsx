import React from "react";
import NavBar from "./NavBar";

function Home() {
  return (
    <>    
    <NavBar/>
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center p-8 bg-white shadow-lg rounded-2xl">

        <h1 className="text-3xl font-bold text-green-600">
          E-Learning Platform
        </h1>

        <p className="text-xl mt-4 text-gray-700">
          YOU'RE WELCOME TO MY E-LEARNING
        </p>

      </div>

    </div>
    </>
  );
}

export default Home;