import React from "react";
import NavBar from "./NavBar";

function Modules() {
  return (
     <>    
    <NavBar/>
    <div className="bg-white text-center p-7">
      
      <h1 className="bg-green-400 text-white py-7 text-4xl rounded-2xl">
        THIS IS MODULES FOR L4 SOD
      </h1>

      <div className="bg-orange-300 mt-5 p-5 rounded-lg">
        <ul className="space-y-3">
          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            Backend System Design
          </li>

          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            Database Development
          </li>

          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            Backend Application Development
          </li>

          <li className="hover:bg-yellow-400 cursor-pointer p-2 rounded">
            Data Structure and Algorithm Fundamentals
          </li>
        </ul>
      </div>

    </div>
    </>
  );
}


export default Modules;