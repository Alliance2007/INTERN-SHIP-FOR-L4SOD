import React from "react";
import { Link } from "react-router-dom";

function NavBar() {
  return (
    <>
    <div className="bg-gray-500 w-full flex items-center justify-center h-20 rounded-2xl">

      <Link to="/" className="bg-yellow-400 m-3 px-4 py-2 hover:bg-white rounded-full">
        HOME
      </Link>

      <Link to="/modules" className="bg-yellow-400 mr-2 px-4 py-2 hover:bg-white rounded-full">
        MODULES
      </Link>

      <Link to="/exams" className="bg-yellow-400 mr-2 px-4 py-2 hover:bg-white rounded-full">
        EXAMS
      </Link>

      <Link to="/about" className="bg-yellow-400 mr-2 px-4 py-2 hover:bg-white rounded-full">
        ABOUT US
      </Link>
    </div>
    </>
  );
}

export default NavBar;